APEX ARMADA PRESS KIT
Max Q Games, 2026-10-01

Free to use for coverage of Apex Armada. Press contact: fonz@maxq.games

TEXT
  fact_sheet.md / fact_sheet.txt   Release, platform, links and contact
  description.md                   Short description, long description, features
  about_max_q_games.md             About the studio
  press_requests.md                How to request a Steam key, and how you may use this kit
  trailer/trailer.md               Trailer link
  00_contents_board.png            Thumbnails of everything in the kit

SCREENSHOTS/
  In-game screenshots, 3840x2160 PNG.
  apex-armada_screenshot-01-battle-pleiadian-vs-draconian_3840x2160.png
  apex-armada_screenshot-02-battle-grey-vs-mantid_3840x2160.png
  apex-armada_screenshot-03-home-port-mantid_3840x2160.png
  apex-armada_screenshot-04-battle-mantid-vs-draconian_3840x2160.png
  apex-armada_screenshot-05-battle-grey-vs-pleiadian_3840x2160.png
  apex-armada_screenshot-06-ship-details-grey_3840x2160.png
  apex-armada_screenshot-07-choose-faction_3840x2160.png
  apex-armada_screenshot-08-versus-screen-draconian-vs-mantid_3840x2160.png
  apex-armada_screenshot-09-world-conqueror_3840x2160.png
  apex-armada_screenshot-10-captain-skills-vraxis_3840x2160.png
  apex-armada_screenshot-11-victory-results-mantid_3840x2160.png
  apex-armada_screenshot-12-ship-details-mantid_3840x2160.png
  apex-armada_screenshot-13-choose-captain-draconian_3840x2160.png
  apex-armada_screenshot-14-battle-pleiadian-hud_3840x2160.png

GIFS/
  Looping gameplay GIFs, one per store page section.
  apex-armada_gif-battle-your-fleet_1232x694.gif
  apex-armada_gif-build-your-fleet_1232x738.gif
  apex-armada_gif-customize_1232x694.gif
  apex-armada_gif-pick-your-captain_1232x630.gif
  apex-armada_gif-upgrade-your-ships_1232x770.gif

KEY_ART/
  Key art with and without the logo, the vertical key art and the library hero (no logo).
  apex-armada_key-art-no-logo_3840x2160.png
  apex-armada_key-art-vertical-with-logo_2048x3072.png
  apex-armada_key-art-with-logo_3840x2160.png
  apex-armada_library-hero-no-logo_3840x1240.png

KEY_ART/SECTION_HEADERS/
  The six store page section headers (transparent PNG).
  apex-armada_header-battle-your-fleet_2400x497.png
  apex-armada_header-build-your-fleet_2400x488.png
  apex-armada_header-conquer-and-rank-up_2400x501.png
  apex-armada_header-customize_2400x405.png
  apex-armada_header-pick-your-captain_2400x388.png
  apex-armada_header-upgrade-your-ships_2400x589.png

KEY_ART/STEAM_SIZES/
  The Steam store and library capsules at Steam's sizes.
  apex-armada_steam-header-capsule_920x430.png
  apex-armada_steam-library-capsule_600x900.png
  apex-armada_steam-main-capsule_1232x706.png
  apex-armada_steam-page-background_1438x810.png
  apex-armada_steam-small-capsule_462x174.png
  apex-armada_steam-vertical-capsule_748x896.png

LOGOS/
  Apex Armada logos as transparent PNG, plus dark-background versions and the Max Q Games studio logo. The bold lockups work on any background. The fine lockups have dark letters, so use them on light backgrounds. The app tile is the emblem on its own dark rounded tile.
  apex-armada_logo-emblem-app-tile_1024x1024.png
  apex-armada_logo-emblem-on-dark_1188x1188.png
  apex-armada_logo-emblem_1024x1024.png
  apex-armada_logo-horizontal-bold-on-dark_2360x1068.png
  apex-armada_logo-horizontal-bold_2034x742.png
  apex-armada_logo-horizontal-fine_2048x641.png
  apex-armada_logo-stacked-bold-on-dark_2420x1324.png
  apex-armada_logo-stacked-bold_2086x990.png
  apex-armada_logo-stacked-fine_2048x1109.png
  apex-armada_logo-wordmark-bold-on-dark_2420x722.png
  apex-armada_logo-wordmark-bold_2086x388.png
  apex-armada_logo-wordmark-fine_2332x267.png
  max-q-games_studio-logo_631x714.png

TRAILER/
  Trailer link and thumbnails (the video file is not in this ZIP).
  apex-armada_demo-trailer-thumbnail_1920x1080.png
  apex-armada_trailer-thumbnail-logo-only_1920x1080.png
  apex-armada_trailer-thumbnail_1920x1080.png
