# Apex Armada: fact sheet

| | |
|---|---|
| Game | Apex Armada |
| Developer | Max Q Games (independent studio) |
| Publisher | Max Q Games (self-published) |
| Release | Full release (1.0), Thursday November 12, 2026 |
| Demo | Free demo coming before launch (Pleiadian Accord and Grey Syndicate factions) |
| Platform | Windows (Steam) |
| Price | TBA |
| Genre | Strategy, Auto Battler |
| Tags | Wargame, 2D, Top-Down, Sci-fi, Space, Spaceships, Aliens, PvP, Combat, Resource Management, Controller, Inventory Management, Asynchronous Multiplayer, Multiplayer, Tactical, Indie, RPG |
| Engine | Godot |
| Website | https://maxq.games/apex-armada/ |
| Steam | https://store.steampowered.com/app/5364730/ |
| Steam demo | https://store.steampowered.com/app/5367190/ |
| Press contact | fonz@maxq.games |
| Discord | https://discord.gg/w8mtQxCcVR |
| X | https://x.com/maxqdev |

## In one line
A spaceship auto battler where you build a fleet to take on real players.
