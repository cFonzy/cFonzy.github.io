# Apex Armada: descriptions

## Short description
A spaceship auto battler where you build a fleet to take on real players. Choose from 16 alien captains to lead your fleet into battle. Spend your gold on ships, guns, shields and other parts. Then watch the battles play out as you climb the ranks to become a Galactic Conqueror.

## Long description
Apex Armada is a spaceship auto battler. You build the fleet. The fight plays out on its own, against a fleet built by a real player. Last ship standing wins.

### PICK YOUR CAPTAIN

Every fleet needs someone in the big chair, and the captain you pick decides how you win.

**PLEIADIAN ACCORD**  
Seren Vael marks a target, and the whole fleet turns its guns on it.  
Ilya Maren stretches his shield over the ships beside him and dares the enemy to break through.  
Lyra Solenne keeps her fleet patched up and flying long after the enemy thinks it's scrap.  
Aurel Venn fills the sky with torpedoes, and every fourth one falls like a star.

**GREY SYNDICATE**  
Ixil slips into your ships' wiring mid-fight and turns your own guns around.  
Oruun slows everything on the other side, guns and skills alike, until the enemy fleet crawls.  
Vess shuts enemy ships down and takes whatever's loose, so even a loss fills the hold.  
Sael's Mothership draws the enemy's fire, and the rest of the fleet hits hard from where nobody is looking.

**DRACONIAN DOMINION**  
Vraxis Kor gets meaner with every kill, his guns firing faster until nothing is left standing.  
Thessk plants his fleet up front, thickens every hull and simply refuses to move.  
Ghalek fires her boarding pods early, and they come back loaded with the enemy's parts.  
Vyrssa sets every ship she hits on fire, and the flames jump down the enemy line.

**MANTID BROOD**  
Sszira sprays acid and backs off, and once the damage starts it never stops.  
Ktharr hatches a fresh drone from every wreck, so you have to chew through the swarm twice.  
Ommol's swarm only gets stronger, and richer, the bigger it grows.  
Zzeth rains spore pods from the back, and every pod that lands splashes the enemy ships around the target.

Every captain flies their own Mothership into battle with a signature skill and new tricks to learn as the run goes on. Most of them talk, too, calling out the big moments mid-fight. And each one sets you an AGENDA: five goals for the run, with a reward for every one you hit.

### BUILD YOUR FLEET

Every round you get gold to spend at the spaceport, and every ship you buy is a choice.

An escort plants itself up front and soaks up the hits. A support ship keeps the others patched up. A siege ship pounds the enemy from the back of the field. A mining ship skips the fight altogether and comes home with gold for next round.

Every faction flies 18 ships of its own, from quick little corvettes to huge battleships. Start small and grow your fleet to ten ships. Then drag them into your battle formation, because who stands at the front and who hangs back changes how the whole fight plays out.

### UPGRADE YOUR SHIPS

A bare ship won't last long out there, and what you bolt on decides how it fights.

A Wormhole Drive drops your ship behind enemy lines to hunt their long-range ships. The Puppeteer cannon makes an enemy fire its next shot at its own side. A Cloak hides your ship until it opens fire. Acid eats through ships, and once it's in, the damage keeps coming.

90 parts across guns, shields, engines and crew, and every port stocks something different. Buy a second copy of a ship and the two become one tougher ship, again and again until it reaches Apex, changes colour and unlocks an Apex Skill of its own. Parts level up the same way, or fuse two different ones into something brand new. And keep an eye out for the Black Market. It sells bonuses nobody else has.

### BATTLE YOUR FLEET

Hit BATTLE, sit back, and watch every choice you made in port play out against a fleet built by a real player.

Boarding pods latch onto a ship whose shields are down and steal it for your side. Mines drift in the open space ahead of your fleet, and the first enemies to charge in fly straight into them. A Mantid swarm hatches fresh drones from its own wrecks, so you have to beat it twice. Then your captain's signature skill swings the whole fight.

Crank it up to four times the speed when you know how it ends. Win and you push on. Lose and it costs you one of your five lives.

### CONQUER & RANK UP

Ten wins makes you a World Conqueror. That's where the real gamble starts.

Double Down for one more fight and a bigger title: System Conqueror, then Sector, then Galactic Conqueror. Lose and the run ends with the title you already earned. Win and you choose again. And every fight you play, win or lose, pushes your rank higher, from Drifter all the way to Void Emperor.

Play Ranked to climb the leaderboard, or play Casual when you just want a good run with nothing on the line. Or take on the Daily Run: every player gets the same captain and the same start, and one shot at the top of the day's board.

### CUSTOMIZE

Make your fleet look like yours, and make sure everyone you fight knows it.

Pick a face for your profile from 64 alien portraits. Wrap it in a frame, and the rarest ones move. Repaint your ships in new colours. Fly your battles under a different sky.

120 pieces to collect, most of them earned as you hit milestones, plus matching sets like Supernova and Black Hole to complete. Your opponents see your look every time you meet.

## Features
- Build a fleet, then watch it fight on its own against a fleet built by a real player. Last ship standing wins.
- Pick one of 16 captains from 4 alien factions. Each one flies a Mothership with a signature skill and sets you an AGENDA of five goals for the run.
- Buy from 18 ships per faction, from quick corvettes to huge battleships, and grow your fleet to ten ships.
- Fit them with 90 parts across guns, shields, engines and crew. Level parts up, or fuse two different ones into something new.
- Buy a second copy of a ship to merge them into one tougher ship, all the way to Apex and its own Apex Skill.
- Set your battle formation. Who stands at the front and who hangs back changes the whole fight.
- Win ten fights to become World Conqueror, then Double Down for System, Sector and Galactic Conqueror.
- Play Ranked, Casual or the Daily Run, and collect 120 cosmetic pieces to make your fleet look like yours.
