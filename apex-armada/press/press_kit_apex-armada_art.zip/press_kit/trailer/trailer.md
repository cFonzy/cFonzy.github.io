# Apex Armada: trailer

Watch the trailer: https://maxq.games/apex-armada/#trailer
Download the trailer (MP4, 1920x1080, 58 seconds): https://maxq.games/apex-armada/media/trailer.mp4

Thumbnails in this folder (1920x1080 PNG):
- `apex-armada_trailer-thumbnail_1920x1080.png`: the main trailer thumbnail
- `apex-armada_trailer-thumbnail-logo-only_1920x1080.png`: the same art with only the logo
- `apex-armada_demo-trailer-thumbnail_1920x1080.png`: the demo trailer thumbnail
