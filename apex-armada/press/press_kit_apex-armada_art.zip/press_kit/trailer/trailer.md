# Apex Armada: trailer

Watch on YouTube: [TRAILER LINK COMING SOON]

A high-quality MP4 download comes with the final cut of the trailer. It is not inside this ZIP because of its size.

Thumbnails in this folder (1920x1080 PNG):
- `apex-armada_trailer-thumbnail_1920x1080.png`: the main trailer thumbnail
- `apex-armada_trailer-thumbnail-logo-only_1920x1080.png`: the same art with only the logo
- `apex-armada_demo-trailer-thumbnail_1920x1080.png`: the demo trailer thumbnail
