# Press and creator requests

## Steam keys
Email **fonz@maxq.games** with:
- your name and your outlet or channel name
- a link to your outlet or channel
- the platform you play on

Keys are sent through Steam. If you are a Steam Curator, we may send you the game through Curator Connect instead.

## Using this kit
You are free to use everything in this kit (screenshots, GIFs, key art, logos, text and the trailer) in your coverage of Apex Armada: articles, reviews, videos and streams, monetized or not. Please don't alter the logos.

Anything else (an interview, more screenshots, a question): fonz@maxq.games.
