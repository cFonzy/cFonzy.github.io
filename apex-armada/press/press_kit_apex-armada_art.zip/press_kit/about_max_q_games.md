# About Max Q Games

Max Q Games is an independent game studio. Apex Armada is our spaceship auto battler, coming to Steam with its 1.0 launch on November 12, 2026.

Website: https://maxq.games · Press: fonz@maxq.games · X: https://x.com/maxqdev · Discord: https://discord.gg/w8mtQxCcVR
